from langchain_community.chat_models.tongyi import (
    ChatTongyi,
)

__all__ = [
    "ChatTongyi",
]
