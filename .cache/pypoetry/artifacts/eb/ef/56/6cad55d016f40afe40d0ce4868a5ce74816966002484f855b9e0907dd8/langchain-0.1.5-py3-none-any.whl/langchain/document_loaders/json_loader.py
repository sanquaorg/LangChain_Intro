from langchain_community.document_loaders.json_loader import JSONLoader

__all__ = ["JSONLoader"]
