from langchain_community.document_loaders.parsers.language.cobol import CobolSegmenter

__all__ = ["CobolSegmenter"]
